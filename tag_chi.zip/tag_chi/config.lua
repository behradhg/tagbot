--NFS source
local _ = {

help = "Help for tag-chi:V4\n/add\n*for add all bot members to group*\n/bot\n*send bot stats*\n/sudolist\n*send list of sudo users*",
..'\n/ping\n*see bot uptime*\n/reload\n*for reload bot*'..'\n/sudo (reply or id)\n*for add sudo user*\n'..'\n/desudo (reply or id)\n*for remove sudo user*\n'..'\n/setbaner (reply)\n*for set bot baner*\n'
..'\n/rembaner (reply)\n*for delet bot baner*\n'
..'\n/getbaner\n*for get bot baner*\n'
..'\n/rconf\n*load config again*\n'
..'\n/setspeed\n*for set baner speed*\n'
..'\n/addall (reply)\n*add person to all bots group*\n'
..'\n/echo (text)\n*echo :|*\n'
..'\n/fwd ("all" or "user" or "gp")\n*fwd a baner*\n'
sudo_users = {
"206637124",
}
}
return _
--by behrad